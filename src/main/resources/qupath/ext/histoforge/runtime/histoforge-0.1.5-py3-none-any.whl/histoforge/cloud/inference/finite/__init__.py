"""HistoForge inference finite owners."""
