"""HistoForge rasterization owners."""
